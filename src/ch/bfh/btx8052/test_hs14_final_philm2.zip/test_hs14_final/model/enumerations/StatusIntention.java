/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bfh.btx8052.test_hs14_final.model.enumerations;

/**
 *
 * @author Reto E. Koenig <reto.koenig@bfh.ch>
 */
public enum StatusIntention {

    Run, Pause, Stop;
}
